/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sbi.logstash.plugin.decryption.model;

import com.sbi.logstash.plugin.decryption.boundary.PIIDecryption;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author Home PC
 */
@Model
public class DecryptionModel {
    
    @Inject
    PIIDecryption pIIDecryption;
    
    private String inputText;

    public String getInputText() {
        return inputText;
    }

    public void setInputText(String inputText) {
        this.inputText = inputText;
    }
    
    
   
    public String callDecryption(){
        
       return pIIDecryption.toDecrypt(inputText);
       
        
    }
    
}
