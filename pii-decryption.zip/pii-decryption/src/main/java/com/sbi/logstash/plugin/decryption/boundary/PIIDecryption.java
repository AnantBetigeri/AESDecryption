/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sbi.logstash.plugin.decryption.boundary;

import javax.ejb.Stateless;
import javax.inject.Inject;
import com.sbi.logstash.plugin.decryption.control.Decryption;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Home PC
 */
@Stateless
public class PIIDecryption {
    
    @Inject
    Decryption decryption;
    
      public String toDecrypt(String inputText){
          
        try {
            return decryption.decrypt(inputText);
        } catch (Exception ex) {
            Logger.getLogger(PIIDecryption.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
      }
      
      
    
}
