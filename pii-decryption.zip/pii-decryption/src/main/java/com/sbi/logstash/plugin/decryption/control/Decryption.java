package com.sbi.logstash.plugin.decryption.control;

import java.io.UnsupportedEncodingException;
import javax.crypto.Cipher;


import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Decryption {
    
    private static final String encryptionKey = "Tt9onBXVxSZ4CcpnFwCJ";
    private static final String characterEncoding = "UTF-8";
    private static final String cipherTransformation = "AES/CBC/PKCS5PADDING";
    private static final String aesEncryptionAlgorithem = "AES";
    private static final byte[] key = toByte();
    private static final Charset UTF_8 = StandardCharsets.UTF_8;
    //private static final Logger logger = LogManager.getLogger(Decryption.class);
    private String decryptedText="";

    public Decryption() {
    }

    public String getDecryptedText() {
        return decryptedText;
    }

    public void setDecryptedText(String decryptedText) {
        this.decryptedText = decryptedText;
    }
    
    
    
    
    public static String decrypt(String encryptedText) throws Exception {

        final SecretKeySpec secretKey = new SecretKeySpec(key, aesEncryptionAlgorithem);
	final IvParameterSpec ivparameterspec = ivSpec();
        Cipher cipher = Cipher.getInstance(cipherTransformation);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivparameterspec);
        byte[] plainText = cipher.doFinal(encryptedText.getBytes(characterEncoding));
        return new String(plainText, UTF_8);
        

    }
    
    private static byte[] toByte() {
		try {
			return encryptionKey.getBytes(characterEncoding);
		} catch (UnsupportedEncodingException e) {
			return null;
		}
	}

	private static IvParameterSpec ivSpec() {
		return new IvParameterSpec(key);
	}

	private static boolean isEmpty(final CharSequence cs) {
		return cs == null || cs.length() == 0;
	}
}
